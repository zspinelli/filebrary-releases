# qt.
from PySide6.QtGui import QPixmap

# pil.
from PIL import Image
from PIL.ImageQt import ImageQt

# stdlib.
from os.path import splitext



_image_formats = ["png", "jpg", "jpeg", "tif", "tga", "gif", "webp"]
_document_formats = ["pdf", "cbz", "epub", "djvu"]
_video_formats = ["webm", "mp4", "mkv", "avi", "mov", "wmv", "flv"]
_archive_formats = ["zip", "rar", "7z"]
_audio_formats = ["mp3", "ogg", "wav", "flac"]



def _delegateGenerateImageThumb():
    pass



def _delegateGenerateDocumentThumb():
    pass



def getPreview(p_path: str, p_height: int, p_width: int) -> QPixmap:
    # Generate an appropriate preview for the desired item.

    # TODO: implement format signature checking in funcs above to replace extension-based checking.

    ext: str = splitext(p_path)[1].replace('.', "")
    preview: QPixmap = QPixmap()

    # Images.
    if ext.lower() in _image_formats:
        thumb: Image = Image.open(p_path)
        thumb.thumbnail( (p_width, p_height) )
        preview = QPixmap.fromImage(ImageQt(thumb))

    # Unhandled.
    else:
        print(f"Previews.py::getPReview(): No preview implementation for extension: {ext}")

    return preview
