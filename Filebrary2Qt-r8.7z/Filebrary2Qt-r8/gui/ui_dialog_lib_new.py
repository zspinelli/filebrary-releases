# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ui_dialog_lib_new.ui'
##
## Created by: Qt User Interface Compiler version 6.3.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QAction, QBrush, QColor, QConicalGradient,
    QCursor, QFont, QFontDatabase, QGradient,
    QIcon, QImage, QKeySequence, QLinearGradient,
    QPainter, QPalette, QPixmap, QRadialGradient,
    QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QDialog, QDialogButtonBox,
    QFormLayout, QFrame, QLabel, QLineEdit,
    QSizePolicy, QVBoxLayout, QWidget)
import filebrary_rc

class Ui_NewLibDialog(object):
    def setupUi(self, NewLibDialog):
        if not NewLibDialog.objectName():
            NewLibDialog.setObjectName(u"NewLibDialog")
        NewLibDialog.setWindowModality(Qt.WindowModal)
        NewLibDialog.resize(320, 120)
        NewLibDialog.setModal(True)
        self.actionPick_path = QAction(NewLibDialog)
        self.actionPick_path.setObjectName(u"actionPick_path")
        icon = QIcon()
        icon.addFile(u":/icons/Document/folder-open-line.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.actionPick_path.setIcon(icon)
        self.verticalLayout = QVBoxLayout(NewLibDialog)
        self.verticalLayout.setSpacing(2)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(2, 2, 2, 2)
        self.frame = QFrame(NewLibDialog)
        self.frame.setObjectName(u"frame")
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.formLayout = QFormLayout(self.frame)
        self.formLayout.setObjectName(u"formLayout")
        self.formLayout.setHorizontalSpacing(2)
        self.formLayout.setVerticalSpacing(2)
        self.formLayout.setContentsMargins(2, 2, 2, 2)
        self.label = QLabel(self.frame)
        self.label.setObjectName(u"label")

        self.formLayout.setWidget(0, QFormLayout.LabelRole, self.label)

        self.name = QLineEdit(self.frame)
        self.name.setObjectName(u"name")
        self.name.setClearButtonEnabled(True)

        self.formLayout.setWidget(0, QFormLayout.FieldRole, self.name)

        self.label_2 = QLabel(self.frame)
        self.label_2.setObjectName(u"label_2")

        self.formLayout.setWidget(1, QFormLayout.LabelRole, self.label_2)

        self.path = QLineEdit(self.frame)
        self.path.setObjectName(u"path")
        self.path.setClearButtonEnabled(True)

        self.formLayout.setWidget(1, QFormLayout.FieldRole, self.path)


        self.verticalLayout.addWidget(self.frame)

        self.buttonBox = QDialogButtonBox(NewLibDialog)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setStandardButtons(QDialogButtonBox.Cancel|QDialogButtonBox.Ok)

        self.verticalLayout.addWidget(self.buttonBox)


        self.retranslateUi(NewLibDialog)

        QMetaObject.connectSlotsByName(NewLibDialog)
    # setupUi

    def retranslateUi(self, NewLibDialog):
        NewLibDialog.setWindowTitle(QCoreApplication.translate("NewLibDialog", u"Filebrary - New library", None))
        self.actionPick_path.setText(QCoreApplication.translate("NewLibDialog", u"Pick path", None))
        self.label.setText(QCoreApplication.translate("NewLibDialog", u"Name:", None))
        self.name.setPlaceholderText(QCoreApplication.translate("NewLibDialog", u"Name the library...", None))
        self.label_2.setText(QCoreApplication.translate("NewLibDialog", u"Path:", None))
        self.path.setPlaceholderText(QCoreApplication.translate("NewLibDialog", u"Pick a library path...", None))
    # retranslateUi

