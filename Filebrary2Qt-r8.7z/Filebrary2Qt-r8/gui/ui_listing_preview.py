# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ui_listing_preview.ui'
##
## Created by: Qt User Interface Compiler version 6.3.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QLabel, QSizePolicy,
    QWidget)

class Ui_PreviewListing(object):
    def setupUi(self, PreviewListing):
        if not PreviewListing.objectName():
            PreviewListing.setObjectName(u"PreviewListing")
        PreviewListing.resize(300, 300)
        PreviewListing.setFrameShape(QFrame.Box)
        PreviewListing.setFrameShadow(QFrame.Plain)
        PreviewListing.setAlignment(Qt.AlignCenter)

        self.retranslateUi(PreviewListing)

        QMetaObject.connectSlotsByName(PreviewListing)
    # setupUi

    def retranslateUi(self, PreviewListing):
        PreviewListing.setText("")
    # retranslateUi

