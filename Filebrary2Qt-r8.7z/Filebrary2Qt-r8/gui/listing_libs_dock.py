# filebrary.
from gui.ui_listing_libs_dock import Ui_LibsDockListing

from core import Library
from gui.dialog_lib_config import ConfigLibDialog

# qt.
from PySide6.QtCore import Slot
from PySide6.QtWidgets import QListWidgetItem, QWidget



class LibsDockListing(QWidget):
    def __init__(self, p_item: QListWidgetItem):
        super().__init__()

        self.item: QListWidgetItem = p_item

        self._ui: Ui_LibsDockListing = Ui_LibsDockListing()
        self._ui.setupUi(self)

        p_item.setSizeHint(self.sizeHint())

        item_index: int = int(p_item.text())
        name_text: str = Library.openDbName(int(p_item.text()))

        self._ui.name.setText(name_text)
        self._ui.eye.setChecked(Library.dbIgnored( int(p_item.text()) ))



    @Slot(bool)
    def on_eye_toggled(self, p_state: bool):
        # Gray the name field and omit the db from searches.

        Library.setDbIgnored(int(self.item.text()), p_state)
        self._ui.name.setEnabled(p_state)

        # TODO: Change the widget background color to signal visibility.



    @Slot()
    def on_config_clicked(self):
        # Open a dialog for the user to configure the library.

        config: ConfigLibDialog = ConfigLibDialog(self)
        config.open()
