#qt.
from PySide6.QtWidgets import QDialog, QWidget

# filebrary.
from gui.ui_dialog_upload import Ui_UploadDialog



class UploadDialog(QDialog):
    def __init__(self, p_parent: QWidget):
        super().__init__(p_parent)

        self._ui: Ui_UploadDialog = Ui_UploadDialog()
        self._ui.setupUi(self)
