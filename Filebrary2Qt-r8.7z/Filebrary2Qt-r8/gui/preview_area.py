# filebrary.
from gui.ui_preview_area import Ui_PreviewArea

from core import Library
from core.record import Record
from gui.dialog_items_edit import EditItemsDialog
from gui.listing_preview import PreviewListing
from Previews import getPreview

# qt.
from PySide6.QtCore import QUrl, Slot
from PySide6.QtGui import QDragEnterEvent, QDropEvent, QResizeEvent
from PySide6.QtWidgets import QWidget, QListWidgetItem

# stdlib.
from math import ceil



class PreviewArea(QWidget):
    PREVIEW_SIZE: int = 180

    # todo: allow user to determine preview size from program settings.

    def __init__(self, p_parent: QWidget):
        super().__init__(p_parent)

        self._listings: dict[int, PreviewListing] = {} # NOTE: {qitem_addr : prevlisting}
        self._selected_indexes: list[int] = []

        self._tilecountH: int = 0
        self._tilecountW: int = 0

        self._lines: int = 0
        self._pages: int = 0

        self._curr_line: int = 0
        self._curr_page: int = 0

        self._ui: Ui_PreviewArea = Ui_PreviewArea()
        self._ui.setupUi(self)

        self._ui.previews.itemSelectionChanged.connect(self._updateSelectedIndices)

        Library.signaller.searchCompleted.connect(self.renewBrowser)



    def _updatePagingInfo(self, p_return: bool):
        # Update the pagination data.

        self._tilecountW = int(self._ui.previews.width() / self.PREVIEW_SIZE)
        self._tilecountH = int(self._ui.previews.height() / self.PREVIEW_SIZE)

        #print("Tiles W: ", self._tilecountW)
        #print("Tiles H: ", self._tilecountH)

        self._lines = int(ceil( Library.searchResultsCount() / self._tilecountW ))
        self._pages = int(ceil( self._lines / self._tilecountH ))

        #print("Lines: ", self._lines)
        #print("Pages: ", self._pages)
        #print()

        # Multiple pages of items to display.
        if self._pages > 1:
            self._ui.scrollbar.setMaximum(ceil(self._lines * 113.5))
            self._ui.scrollbar.setEnabled(True)

            # Return scrollbar.
            if p_return: self._ui.scrollbar.setValue(0)

        # Single page or less of items to display.
        else:
            self._ui.scrollbar.setEnabled(False)



    def _updatePreviews(self):
        # Update the list of preview items.

        self._ui.previews.clear()

        for i in range(Library.searchResultsCount()):
            item: QListWidgetItem = QListWidgetItem()
            item.setText(str(i))
            self._ui.previews.addItem(item)

            widget: PreviewListing = PreviewListing(item)
            widget.setPixmap(getPreview(
                Library.resultAtIndex(i).url(),
                self.PREVIEW_SIZE,
                self.PREVIEW_SIZE
            ))
            self._ui.previews.setItemWidget(item, widget)

            self._listings.update({id(item): widget})



    def _updateSelectedIndices(self):
        # Update the list of selected item indices.

        #for item in self._ui.previews.selectedItems():
            #print("index: ", item.text())
            #print("lib: ", Library.resultAtIndex(int(item.text())).url())

        pass



    def selectedItems(self) -> list[Record]:
        # Returns a list of urls from selected items.

        selected: list[Record] = []

        for index in self._selected_indexes:
            selected.append(Library.resultAtIndex(index))

        return selected



    @Slot(int)
    def on_scrollbar_valueChanged(self, p_value: int):
        # Scroll the preview list.

        self._curr_line = p_value
        page: int = int(self._curr_line / self._tilecountH)

        self._ui.previews.verticalScrollBar().setValue(p_value)



    @Slot()
    def renewBrowser(self):
        # Update and reset the browser for new search results.

        self._updatePagingInfo(True)
        self._updatePreviews()



    def dragEnterEvent(self, p_drag: QDragEnterEvent):
        # Determine if drop events should be permitted.

        # At least one database is open to receive items.
        if Library.openDbsCount() > 0 and p_drag.mimeData().hasUrls():
            p_drag.accept(self.rect())

        else:
            p_drag.ignore(self.rect())



    def dropEvent(self, p_drop: QDropEvent):
        # Handle dropped filepaths.

        urls: list[QUrl] = p_drop.mimeData().urls()
        items: list[Record] = []

        for url in urls:
            items.append(Record(url.toLocalFile(), "", "", []))

        fedit: EditItemsDialog = EditItemsDialog(self, "Filebrary - Import Items", "Import")
        fedit.addItems(items)
        fedit.open()



    def resizeEvent(self, p_resize: QResizeEvent):
        # Determine if the number of preview items needs adjusted.

        x_eval: int = int(self._ui.previews.width() / self.PREVIEW_SIZE)
        y_eval: int = int(ceil(self._ui.previews.height() / self.PREVIEW_SIZE)) + 1

        # The number of available previews should change.
        if x_eval != self._tilecountW or y_eval != self._tilecountH:
            self._updatePagingInfo(False)
