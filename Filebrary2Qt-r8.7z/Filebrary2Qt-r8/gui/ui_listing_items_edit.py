# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ui_listing_items_edit.ui'
##
## Created by: Qt User Interface Compiler version 6.3.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QAction, QBrush, QColor, QConicalGradient,
    QCursor, QFont, QFontDatabase, QGradient,
    QIcon, QImage, QKeySequence, QLinearGradient,
    QPainter, QPalette, QPixmap, QRadialGradient,
    QTransform)
from PySide6.QtWidgets import (QApplication, QComboBox, QHBoxLayout, QLabel,
    QLineEdit, QSizePolicy, QSpacerItem, QVBoxLayout,
    QWidget)

class Ui_EditItemsListing(object):
    def setupUi(self, EditItemsListing):
        if not EditItemsListing.objectName():
            EditItemsListing.setObjectName(u"EditItemsListing")
        EditItemsListing.resize(400, 160)
        sizePolicy = QSizePolicy(QSizePolicy.Minimum, QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(EditItemsListing.sizePolicy().hasHeightForWidth())
        EditItemsListing.setSizePolicy(sizePolicy)
        self.editdesc = QAction(EditItemsListing)
        self.editdesc.setObjectName(u"editdesc")
        self.horizontalLayout = QHBoxLayout(EditItemsListing)
        self.horizontalLayout.setSpacing(2)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(2, 2, 2, 2)
        self.thumb = QLabel(EditItemsListing)
        self.thumb.setObjectName(u"thumb")
        sizePolicy1 = QSizePolicy(QSizePolicy.MinimumExpanding, QSizePolicy.Minimum)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.thumb.sizePolicy().hasHeightForWidth())
        self.thumb.setSizePolicy(sizePolicy1)
        self.thumb.setAlignment(Qt.AlignCenter)

        self.horizontalLayout.addWidget(self.thumb)

        self.widget = QWidget(EditItemsListing)
        self.widget.setObjectName(u"widget")
        sizePolicy2 = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Minimum)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.widget.sizePolicy().hasHeightForWidth())
        self.widget.setSizePolicy(sizePolicy2)
        self.verticalLayout = QVBoxLayout(self.widget)
        self.verticalLayout.setSpacing(2)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(2, 2, 2, 2)
        self.lib = QComboBox(self.widget)
        self.lib.setObjectName(u"lib")
        sizePolicy2.setHeightForWidth(self.lib.sizePolicy().hasHeightForWidth())
        self.lib.setSizePolicy(sizePolicy2)

        self.verticalLayout.addWidget(self.lib)

        self.name = QLineEdit(self.widget)
        self.name.setObjectName(u"name")
        sizePolicy3 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.name.sizePolicy().hasHeightForWidth())
        self.name.setSizePolicy(sizePolicy3)
        self.name.setClearButtonEnabled(True)

        self.verticalLayout.addWidget(self.name)

        self.desc = QLineEdit(self.widget)
        self.desc.setObjectName(u"desc")
        sizePolicy3.setHeightForWidth(self.desc.sizePolicy().hasHeightForWidth())
        self.desc.setSizePolicy(sizePolicy3)
        self.desc.setClearButtonEnabled(True)

        self.verticalLayout.addWidget(self.desc)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer)


        self.horizontalLayout.addWidget(self.widget)


        self.retranslateUi(EditItemsListing)

        QMetaObject.connectSlotsByName(EditItemsListing)
    # setupUi

    def retranslateUi(self, EditItemsListing):
        EditItemsListing.setWindowTitle(QCoreApplication.translate("EditItemsListing", u"Form", None))
        self.editdesc.setText(QCoreApplication.translate("EditItemsListing", u"...", None))
        self.thumb.setText(QCoreApplication.translate("EditItemsListing", u"Placeholder", None))
        self.lib.setPlaceholderText(QCoreApplication.translate("EditItemsListing", u"Choose library", None))
        self.name.setPlaceholderText(QCoreApplication.translate("EditItemsListing", u"Name", None))
        self.desc.setText("")
        self.desc.setPlaceholderText(QCoreApplication.translate("EditItemsListing", u"Description", None))
    # retranslateUi

