# filebrary.
from gui.ui_dialog_lib_new import Ui_NewLibDialog

# qt.
from PySide6.QtCore import Signal, Slot
from PySide6.QtWidgets import QDialog, QFileDialog, QLineEdit, QWidget

# stdlib.
from os.path import isdir



class NewLibDialog(QDialog):
    finalized: Signal = Signal(str, str)

    _INVALID_CHARS: str = "\\/:*?\"<>|"

    def __init__(self, p_parent: QWidget):
        super().__init__(p_parent)

        self._ui: Ui_NewLibDialog = Ui_NewLibDialog()
        self._ui.setupUi(self)

        self._ui.path.addAction(self._ui.actionPick_path, QLineEdit.TrailingPosition)



    @Slot()
    def on_actionPick_path_triggered(self):
        # Open a dialog for the user to choose a path for the new library.

        path = QFileDialog.getExistingDirectory(
            self,
            "Choose destination",
            "/home"
        )
        self._ui.path.setText(path)



    @Slot(str)
    def on_path_textEdited(self, p_text: str):
        # Cut invalid characters out of the path field.

        for char in self._INVALID_CHARS:
            if char in p_text:
                p_text.replace(char, '')

        self._ui.path.setText(p_text)



    @Slot(str)
    def on_name_textEdited(self, p_text):
        # Cut invalid characters out of the name field.

        if p_text != "" and p_text[-1] in self._INVALID_CHARS:
            self._ui.name.setText(p_text[:-1])



    @Slot()
    def on_buttonBox_accepted(self):
        # Accept and close the dialog if fields have valid input.

        if(
            self._ui.name.text() and
            isdir(self._ui.path.text())
        ):
            self.finalized.emit(self._ui.path.text(), self._ui.name.text())
            self.accept()



    @Slot()
    def on_buttonBox_rejected(self):
        # Reject and close the dialog.

        self.reject()
