# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ui_preview_area.ui'
##
## Created by: Qt User Interface Compiler version 6.3.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QHBoxLayout, QListView, QListWidget,
    QListWidgetItem, QScrollBar, QSizePolicy, QWidget)

class Ui_PreviewArea(object):
    def setupUi(self, PreviewArea):
        if not PreviewArea.objectName():
            PreviewArea.setObjectName(u"PreviewArea")
        PreviewArea.resize(619, 600)
        PreviewArea.setAcceptDrops(True)
        self.horizontalLayout = QHBoxLayout(PreviewArea)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(2, 2, 2, 2)
        self.previews = QListWidget(PreviewArea)
        self.previews.setObjectName(u"previews")
        self.previews.setAcceptDrops(False)
        self.previews.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.previews.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.previews.setResizeMode(QListView.Adjust)
        self.previews.setViewMode(QListView.IconMode)
        self.previews.setUniformItemSizes(True)

        self.horizontalLayout.addWidget(self.previews)

        self.scrollbar = QScrollBar(PreviewArea)
        self.scrollbar.setObjectName(u"scrollbar")
        self.scrollbar.setMaximum(0)
        self.scrollbar.setOrientation(Qt.Vertical)

        self.horizontalLayout.addWidget(self.scrollbar)


        self.retranslateUi(PreviewArea)

        QMetaObject.connectSlotsByName(PreviewArea)
    # setupUi

    def retranslateUi(self, PreviewArea):
        PreviewArea.setWindowTitle(QCoreApplication.translate("PreviewArea", u"Form", None))
    # retranslateUi

