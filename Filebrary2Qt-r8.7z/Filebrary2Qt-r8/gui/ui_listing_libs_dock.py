# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ui_listing_libs_dock.ui'
##
## Created by: Qt User Interface Compiler version 6.3.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QHBoxLayout, QLabel, QPushButton,
    QSizePolicy, QWidget)
import filebrary_rc

class Ui_LibsDockListing(object):
    def setupUi(self, LibsDockListing):
        if not LibsDockListing.objectName():
            LibsDockListing.setObjectName(u"LibsDockListing")
        LibsDockListing.resize(300, 42)
        sizePolicy = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Maximum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(LibsDockListing.sizePolicy().hasHeightForWidth())
        LibsDockListing.setSizePolicy(sizePolicy)
        self.horizontalLayout = QHBoxLayout(LibsDockListing)
        self.horizontalLayout.setSpacing(2)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(4, 4, 4, 4)
        self.eye = QPushButton(LibsDockListing)
        self.eye.setObjectName(u"eye")
        sizePolicy1 = QSizePolicy(QSizePolicy.Maximum, QSizePolicy.Maximum)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.eye.sizePolicy().hasHeightForWidth())
        self.eye.setSizePolicy(sizePolicy1)
        icon = QIcon()
        icon.addFile(u":/icons/System/eye-line.svg", QSize(), QIcon.Normal, QIcon.Off)
        icon.addFile(u":/icons/System/eye-close-line.svg", QSize(), QIcon.Normal, QIcon.On)
        self.eye.setIcon(icon)
        self.eye.setCheckable(True)

        self.horizontalLayout.addWidget(self.eye)

        self.config = QPushButton(LibsDockListing)
        self.config.setObjectName(u"config")
        sizePolicy1.setHeightForWidth(self.config.sizePolicy().hasHeightForWidth())
        self.config.setSizePolicy(sizePolicy1)
        icon1 = QIcon()
        icon1.addFile(u":/icons/Design/tools-line.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.config.setIcon(icon1)

        self.horizontalLayout.addWidget(self.config)

        self.name = QLabel(LibsDockListing)
        self.name.setObjectName(u"name")
        sizePolicy.setHeightForWidth(self.name.sizePolicy().hasHeightForWidth())
        self.name.setSizePolicy(sizePolicy)

        self.horizontalLayout.addWidget(self.name)


        self.retranslateUi(LibsDockListing)

        QMetaObject.connectSlotsByName(LibsDockListing)
    # setupUi

    def retranslateUi(self, LibsDockListing):
        LibsDockListing.setWindowTitle(QCoreApplication.translate("LibsDockListing", u"Form", None))
        self.eye.setText("")
        self.config.setText("")
        self.name.setText(QCoreApplication.translate("LibsDockListing", u"Library name placeholder", None))
    # retranslateUi

