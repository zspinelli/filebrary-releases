# qt.
from PySide6.QtCore import Qt, Slot
from PySide6.QtGui import QKeyEvent
from PySide6.QtWidgets import QDialog, QWidget, QLineEdit, QListWidgetItem

# filebrary.
from gui.ui_dialog_items_edit import Ui_EditItemsDialog

from core import Library
from core.record import Record
from gui.listing_items_edit import EditItemsListing

# stdlib.
import asyncio
from copy import copy
from os.path import dirname



class EditItemsDialog(QDialog):
    def __init__(self, p_parent: QWidget, p_title: str, p_action: str):
        super().__init__(p_parent)

        self._item_widgets: dict[int, EditItemsListing] = {} # NOTE: {qitem_addr : editlisting}

        self._ui: Ui_EditItemsDialog = Ui_EditItemsDialog()
        self._ui.setupUi(self)

        self.setWindowTitle(p_title)
        self._ui.actiongroup.setTitle(p_action)



    def _updateUsedList(self):
        # Update the list of tags used in all open libraries.

        tags: list[str] = Library.allTags()

        self._ui.usedlist.clear()
        self._ui.usedlist.addItems(tags)



    def _updateLocalLists(self, p_all: bool):
        # Update the lists of tags on candidates items.

        # Note:
        # Used tags and selected tags will almost never be updated
        # separately and updating used tags requires looping over all
        # the tags individually, so updating in either circumstance is
        # handled efficiently enough in one method with a mode switch.

        all_tags: list[str] = []
        sel_tags: list[str] = []

        for widget in self._item_widgets.values():
            for tag in widget.tags():
                # Update all.
                if p_all and tag not in all_tags:
                    all_tags.append(tag)

                # Update selected.
                if widget.item.isSelected() and tag not in sel_tags:
                    sel_tags.append(tag)

            # ---- Sort and deduplicate tag lists. ---- #

            # Update all.
            if p_all:
                list(set(all_tags)).sort()

            list(set(sel_tags)).sort()

        # ---- Update tag list widgets. ---- #

        # Update all.
        if p_all:
            self._ui.alllist.clear()
            self._ui.alllist.addItems(all_tags)

        self._ui.sellist.clear()
        self._ui.sellist.addItems(sel_tags)



    def _delegateProcess(self, p_all: bool):
        # Deduplicate import functionality from on_confirmx_clicked methods.

        imports: list[Record] = self.items(p_all)
        imported: list[str] = Library.addRecords(imports)
        self.removeItems(imported)

        # TODO: produce notifications for items that couldn't be imported



    def _delegateAddTags(self, p_all: bool, p_line: QLineEdit):
        # Deduplicates on_addx_returnPressed functionality.

        tags: list[str] = p_line.text().split(';')

        for widget in self._item_widgets.values():
            # Add to selected items only.
            if not p_all and not widget.item.isSelected():
                continue

            for tag in tags:
                widget.addTag(tag.strip())

        p_line.clear()

        self._updateLocalLists(True)



    async def _delegateAddAsync(self, p_rec: Record): # -> tuple(str, int)
        # Asynchronously add the record to the editing list.

        # Rec url is already listed.
        if self._ui.editlist.findItems(p_rec.url(), Qt.MatchExactly):
            return (1, p_rec.url())

        # Rec url is under a database.
        elif Library.urlUnderDb(dirname(p_rec.url())):
            return (2, p_rec.url())

        # Rec url not already listed or under a database.
        else:
            # ---- Create the new list item. ---- #

            item: QListWidgetItem = QListWidgetItem()
            self._ui.editlist.addItem(item)

            # ---- Associate the list item to a widget. ---- #

            listing: EditItemsListing = EditItemsListing(item, p_rec)
            self._ui.editlist.setItemWidget(item, listing)
            listing.updatePreview()

            # ---- Catalog the list item id and widget. ---- #

            self._item_widgets.update({id(item): listing})

            return (0, "")



    async def _delegateAddItemsAsync(self, p_recs: list[Record]): # -> list[tuple]
        # Add one or more candidate items.

        errors: list[tuple] = []

        for future in asyncio.as_completed(map(self._delegateAddAsync, p_recs)):
            result = await future

            # Item was already added.
            if result[0] != 0: errors.append(result)

        return errors



    def addItems(self, p_recs: list[Record]):
        # Wrap asynchronous procedure to call from non-async code.

        errors = asyncio.run(self._delegateAddItemsAsync(p_recs))



    def removeItems(self, p_urls: list[str]):
        # Remove one or more candidate items.

        for item_id in copy(list(self._item_widgets.keys())):
            list_item: EditItemsListing = self._item_widgets[item_id]

            # Item has matching url.
            if list_item.url() in p_urls:
                del self._item_widgets[item_id]
                row: int = self._ui.editlist.row(list_item.item)
                self._ui.editlist.takeItem(row)

        self._updateLocalLists(True)



    def items(self, p_all: bool) -> list[Record]:
        # Returns a list of all or selected listings as records.

        records: list[Record] = []

        for widget in self._item_widgets.values():
            # Listing is unselected; Only selected wanted.
            if not p_all and not widget.item.isSelected():
                continue

            records.append(widget.record())

        return records



    @Slot(QListWidgetItem)
    def on_editlist_itemClicked(self, p_item: QListWidgetItem):
        # React to an item getting clicked.

        self._updateLocalLists(False)



    @Slot()
    def on_addall_returnPressed(self):
        # Add the proposed tag to all candidates.

        self._delegateAddTags(True, self._ui.addall)



    @Slot()
    def on_addsel_returnPressed(self):
        # Add the proposed tag to all selected candidates.

        self._delegateAddTags(True, self._ui.addsel)



    @Slot()
    def on_searchused_textEdited(self):
        pass



    @Slot()
    def on_searchall_textEdited(self):
        pass



    @Slot()
    def on_searchsel_textEdited(self):
        pass



    @Slot()
    def on_confirmall_clicked(self):
        # Import all configured candidate items.

        self._delegateProcess(True)



    @Slot()
    def on_confirmsel_clicked(self):
        # Import selected configured candidate items.

        self._delegateProcess(False)



    @Slot()
    def on_done_clicked(self):
        # Confirm and close the dialog.

        self.accept()



    def keyPressEvent(self, p_key: QKeyEvent):
        # Produces empty behavior to prevent undesirable behavior when the Enter key is pressed.

        pass
