# qt.
from PySide6.QtCore import Slot
from PySide6.QtWidgets import QMainWindow, QMessageBox

# filebrary.
from gui.ui_mainwindow import Ui_MainWindow

from core import Library
from core.record import Record
from gui.mbox_item_delete import DeleteItemsDialog
from gui.dialog_download import DownloadDialog
from gui.dialog_items_edit import EditItemsDialog
from gui.dialog_settings import SettingsDialog
from gui.dialog_upload import UploadDialog



class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self._ui: Ui_MainWindow = Ui_MainWindow()
        self._ui.setupUi(self)

        # todo: retrieve geometry info from config.

        self.show()



    @Slot()
    def on_actionSettings_triggered(self):
        # Open a dialog for the user to configure Filebrary.

        settings_dialog: SettingsDialog = SettingsDialog(self)
        settings_dialog.open()



    @Slot()
    def on_actionAbout_triggered(self):
        # Open a dialog with basic information about the program.

        QMessageBox.about(
            self,
            "About Filebrary",
            "Another one of Miyazaki's stupid programs.\n\n"
            "Core model 2\n"
            "GUI model 3\n"
            "Release 8"
        )



    @Slot()
    def on_actionUpload_triggered(self):
        # Open a dialog for the user to send databases to other users.

        upload_dialog: UploadDialog = UploadDialog(self)
        upload_dialog.open()



    @Slot()
    def on_actionDownload_triggered(self):
        # Open a dialog for the user to receive databases from other users.

        download_dialog: DownloadDialog = DownloadDialog(self)
        download_dialog.open()



    @Slot()
    def on_actionAdd_triggered(self):
        # Open a dialog to add new records.

        add_dialog: EditItemsDialog = EditItemsDialog(self, "Filebrary - Add items", "Add")
        add_dialog.open()



    @Slot()
    def on_actionEdit_triggered(self):
        # Open a dialog to edit existing records.

        items: list[Record] = self._ui.preview_area.selectedItems()

        edit_dialog: EditItemsDialog = EditItemsDialog(self, "Filebrary - Edit items", "Edit")
        edit_dialog.addItems(items)
        edit_dialog.open()



    @Slot()
    def on_actionImport_triggered(self):
        # Import freestanding records.

        pass



    @Slot()
    def on_actionExport_triggered(self):
        # Export selected records.

        pass



    @Slot()
    def on_actionDelete_triggered(self):
        # Delete selected records.

        delete_dialog: DeleteItemsDialog = DeleteItemsDialog()

        # User confirmed deletion.
        if delete_dialog.exec() == delete_dialog.Yes:
            records: list[Record] = self._ui.preview_area.selectedItems()
            Library.deleteRecords(records)
