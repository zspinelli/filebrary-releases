# qt.
from PySide6.QtCore import Slot
from PySide6.QtWidgets import QInputDialog, QListWidgetItem, QWidget

# filebrary.
from gui.ui_listing_items_edit import Ui_EditItemsListing

import Previews
from core import Library
from core.record import Record

# stdlib.
from copy import copy



class EditItemsListing(QWidget):
    def __init__(self, p_item: QListWidgetItem, p_rec: Record):
        super().__init__()

        self.item: QListWidgetItem = p_item
        self._rec: Record = p_rec

        # ---- Build the ui. ---- #

        self._ui: Ui_EditItemsListing = Ui_EditItemsListing()
        self._ui.setupUi(self)

        p_item.setSizeHint(self.sizeHint())

        # ---- Configure the ui data. ---- #

        self._ui.lib.addItems(["<Library>"])
        self._ui.lib.addItems(Library.openDbsNames())
        self._ui.lib.setCurrentIndex(self._rec.db() + 1)

        self.item.setText(p_rec.url())

        self._ui.name.setText(p_rec.name())
        self._ui.desc.setText(p_rec.desc())
        self._tags = p_rec.tags()



    def url(self) -> str:           return self._rec.url()
    def tags(self) -> list[str]:    return copy(self._tags)



    def updatePreview(self):
        # Configure the preview image.

        # TODO: centralize preview generation threading in preview module.

        self._ui.thumb.setPixmap(
            Previews.getPreview(
                self.item.text(),
                self._ui.thumb.width(),
                self._ui.thumb.height()
            )
        )



    def addTag(self, p_tag: str):
        # Add a tag to the item.

        # Desired tag not applied.
        if p_tag not in self._tags:
            self._tags.append(p_tag)



    def removeTag(self, p_tag: str):
        # Remove a tag from the item.

        self._tags.remove(p_tag)



    def record(self) -> Record:
        # Returns the record with new properties.

        return Record(
            self._rec.url(),
            self._ui.name.text(),
            self._ui.desc.text(),
            self._tags,
            Library.openDbId(self._ui.lib.currentText())
        )



    @Slot()
    def on_editdesc_triggered(self):
        # Open a larger text editing prompt for more detailed text.

        new_desc: tuple[str, bool] = QInputDialog.getMultiLineText(
            self,
            "Edit item description",
            "Description:",
            self._ui.desc.text()
        )

        # Description was edited.
        if new_desc:
            self._ui.desc.setText(new_desc[0])
