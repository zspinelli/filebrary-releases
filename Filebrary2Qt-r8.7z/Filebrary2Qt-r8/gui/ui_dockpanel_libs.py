# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ui_dockpanel_libs.ui'
##
## Created by: Qt User Interface Compiler version 6.3.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QHBoxLayout, QListWidget, QListWidgetItem,
    QPushButton, QSizePolicy, QSpacerItem, QToolButton,
    QVBoxLayout, QWidget)
import filebrary_rc

class Ui_LibsDockPanel(object):
    def setupUi(self, LibsDockPanel):
        if not LibsDockPanel.objectName():
            LibsDockPanel.setObjectName(u"LibsDockPanel")
        LibsDockPanel.resize(333, 400)
        self.verticalLayout = QVBoxLayout(LibsDockPanel)
        self.verticalLayout.setSpacing(2)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(2, 2, 2, 2)
        self.widget = QWidget(LibsDockPanel)
        self.widget.setObjectName(u"widget")
        self.horizontalLayout = QHBoxLayout(self.widget)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.newlib = QPushButton(self.widget)
        self.newlib.setObjectName(u"newlib")

        self.horizontalLayout.addWidget(self.newlib)

        self.openlib = QPushButton(self.widget)
        self.openlib.setObjectName(u"openlib")

        self.horizontalLayout.addWidget(self.openlib)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer)

        self.unloadlib = QToolButton(self.widget)
        self.unloadlib.setObjectName(u"unloadlib")
        icon = QIcon()
        icon.addFile(u":/icons/System/logout-box-r-line.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.unloadlib.setIcon(icon)

        self.horizontalLayout.addWidget(self.unloadlib)

        self.deletelib = QToolButton(self.widget)
        self.deletelib.setObjectName(u"deletelib")
        icon1 = QIcon()
        icon1.addFile(u":/icons/System/delete-bin-2-line.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.deletelib.setIcon(icon1)

        self.horizontalLayout.addWidget(self.deletelib)


        self.verticalLayout.addWidget(self.widget)

        self.liblist = QListWidget(LibsDockPanel)
        self.liblist.setObjectName(u"liblist")
        self.liblist.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)

        self.verticalLayout.addWidget(self.liblist)


        self.retranslateUi(LibsDockPanel)

        QMetaObject.connectSlotsByName(LibsDockPanel)
    # setupUi

    def retranslateUi(self, LibsDockPanel):
        LibsDockPanel.setWindowTitle(QCoreApplication.translate("LibsDockPanel", u"Widget", None))
        self.newlib.setText(QCoreApplication.translate("LibsDockPanel", u"New", None))
        self.openlib.setText(QCoreApplication.translate("LibsDockPanel", u"Open", None))
        self.unloadlib.setText(QCoreApplication.translate("LibsDockPanel", u"...", None))
        self.deletelib.setText(QCoreApplication.translate("LibsDockPanel", u"...", None))
    # retranslateUi

