# qt.
from PySide6.QtGui import QKeyEvent
from PySide6.QtWidgets import QMessageBox



class DeleteItemsDialog(QMessageBox):
    def __init__(self):
        super().__init__()

        self.setStandardButtons(self.Yes | self.No)
        self.setIcon(self.Warning)

        self.setWindowTitle("Filebrary - Delete items")
        self.setText("WARNING - THIS IS PERMANENT AND NON-REVERSIBLE!")
        self.setInformativeText("Are you sure you chose the right action?")



    def keyPressEvent(self, event: QKeyEvent):
        # Ignore keyboard input to prevent unwanted behavior.

        pass
