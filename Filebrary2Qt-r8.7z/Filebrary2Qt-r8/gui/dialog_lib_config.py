# filebrary.
from gui.ui_dialog_lib_config import Ui_ConfigLibDialog

# qt.
from PySide6.QtWidgets import QDialog, QWidget



class ConfigLibDialog(QDialog):
    def __init__(self, p_parent: QWidget):
        super().__init__(p_parent)

        self._ui: Ui_ConfigLibDialog = Ui_ConfigLibDialog()
        self._ui.setupUi(self)
