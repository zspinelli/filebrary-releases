# qt.
from PySide6.QtCore import Slot
from PySide6.QtWidgets import QDialog, QWidget

# filebrary.
from gui.ui_dialog_settings import Ui_SettingsDialog



class SettingsDialog(QDialog):
    def __init__(self, p_parent: QWidget):
        super().__init__(p_parent)

        self._ui: Ui_SettingsDialog = Ui_SettingsDialog()
        self._ui.setupUi(self)



    @Slot()
    def on_buttonBox_accepted(self):
        # Accept and close the dialog.

        self.accept()
