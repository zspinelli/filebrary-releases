# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ui_dialog_items_edit.ui'
##
## Created by: Qt User Interface Compiler version 6.3.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QDialog, QFrame,
    QGroupBox, QHBoxLayout, QLineEdit, QListWidget,
    QListWidgetItem, QPushButton, QSizePolicy, QSpacerItem,
    QSplitter, QVBoxLayout, QWidget)

class Ui_EditItemsDialog(object):
    def setupUi(self, EditItemsDialog):
        if not EditItemsDialog.objectName():
            EditItemsDialog.setObjectName(u"EditItemsDialog")
        EditItemsDialog.setWindowModality(Qt.WindowModal)
        EditItemsDialog.resize(600, 600)
        EditItemsDialog.setModal(True)
        self.verticalLayout = QVBoxLayout(EditItemsDialog)
        self.verticalLayout.setSpacing(2)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(2, 2, 2, 2)
        self.panel = QWidget(EditItemsDialog)
        self.panel.setObjectName(u"panel")
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.panel.sizePolicy().hasHeightForWidth())
        self.panel.setSizePolicy(sizePolicy)
        self.horizontalLayout_3 = QHBoxLayout(self.panel)
        self.horizontalLayout_3.setSpacing(2)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(2, 2, 2, 2)
        self.splitter_2 = QSplitter(self.panel)
        self.splitter_2.setObjectName(u"splitter_2")
        self.splitter_2.setOrientation(Qt.Horizontal)
        self.editlist = QListWidget(self.splitter_2)
        self.editlist.setObjectName(u"editlist")
        self.editlist.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self.editlist.setSelectionMode(QAbstractItemView.MultiSelection)
        self.splitter_2.addWidget(self.editlist)
        self.splitter = QSplitter(self.splitter_2)
        self.splitter.setObjectName(u"splitter")
        self.splitter.setOrientation(Qt.Vertical)
        self.groupBox_3 = QGroupBox(self.splitter)
        self.groupBox_3.setObjectName(u"groupBox_3")
        self.groupBox_3.setAlignment(Qt.AlignCenter)
        self.verticalLayout_4 = QVBoxLayout(self.groupBox_3)
        self.verticalLayout_4.setSpacing(2)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(2, 2, 2, 2)
        self.searchused = QLineEdit(self.groupBox_3)
        self.searchused.setObjectName(u"searchused")
        self.searchused.setClearButtonEnabled(True)

        self.verticalLayout_4.addWidget(self.searchused)

        self.usedlist = QListWidget(self.groupBox_3)
        self.usedlist.setObjectName(u"usedlist")
        self.usedlist.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)

        self.verticalLayout_4.addWidget(self.usedlist)

        self.splitter.addWidget(self.groupBox_3)
        self.groupBox_4 = QGroupBox(self.splitter)
        self.groupBox_4.setObjectName(u"groupBox_4")
        self.groupBox_4.setAlignment(Qt.AlignCenter)
        self.verticalLayout_3 = QVBoxLayout(self.groupBox_4)
        self.verticalLayout_3.setSpacing(2)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(2, 2, 2, 2)
        self.searchall = QLineEdit(self.groupBox_4)
        self.searchall.setObjectName(u"searchall")
        self.searchall.setClearButtonEnabled(True)

        self.verticalLayout_3.addWidget(self.searchall)

        self.alllist = QListWidget(self.groupBox_4)
        self.alllist.setObjectName(u"alllist")
        self.alllist.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)

        self.verticalLayout_3.addWidget(self.alllist)

        self.addall = QLineEdit(self.groupBox_4)
        self.addall.setObjectName(u"addall")
        self.addall.setClearButtonEnabled(True)

        self.verticalLayout_3.addWidget(self.addall)

        self.splitter.addWidget(self.groupBox_4)
        self.groupBox_5 = QGroupBox(self.splitter)
        self.groupBox_5.setObjectName(u"groupBox_5")
        self.groupBox_5.setAlignment(Qt.AlignCenter)
        self.verticalLayout_2 = QVBoxLayout(self.groupBox_5)
        self.verticalLayout_2.setSpacing(2)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(2, 2, 2, 2)
        self.searchsel = QLineEdit(self.groupBox_5)
        self.searchsel.setObjectName(u"searchsel")
        self.searchsel.setClearButtonEnabled(True)

        self.verticalLayout_2.addWidget(self.searchsel)

        self.sellist = QListWidget(self.groupBox_5)
        self.sellist.setObjectName(u"sellist")
        self.sellist.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)

        self.verticalLayout_2.addWidget(self.sellist)

        self.addsel = QLineEdit(self.groupBox_5)
        self.addsel.setObjectName(u"addsel")
        self.addsel.setClearButtonEnabled(True)

        self.verticalLayout_2.addWidget(self.addsel)

        self.splitter.addWidget(self.groupBox_5)
        self.splitter_2.addWidget(self.splitter)

        self.horizontalLayout_3.addWidget(self.splitter_2)


        self.verticalLayout.addWidget(self.panel)

        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setSpacing(2)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(2, 2, 2, 2)
        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer)

        self.actiongroup = QGroupBox(EditItemsDialog)
        self.actiongroup.setObjectName(u"actiongroup")
        sizePolicy1 = QSizePolicy(QSizePolicy.Minimum, QSizePolicy.Maximum)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.actiongroup.sizePolicy().hasHeightForWidth())
        self.actiongroup.setSizePolicy(sizePolicy1)
        self.actiongroup.setAlignment(Qt.AlignCenter)
        self.horizontalLayout = QHBoxLayout(self.actiongroup)
        self.horizontalLayout.setSpacing(2)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(2, 2, 2, 2)
        self.confirmall = QPushButton(self.actiongroup)
        self.confirmall.setObjectName(u"confirmall")

        self.horizontalLayout.addWidget(self.confirmall)

        self.confirmsel = QPushButton(self.actiongroup)
        self.confirmsel.setObjectName(u"confirmsel")

        self.horizontalLayout.addWidget(self.confirmsel)

        self.line = QFrame(self.actiongroup)
        self.line.setObjectName(u"line")
        self.line.setFrameShape(QFrame.VLine)
        self.line.setFrameShadow(QFrame.Sunken)

        self.horizontalLayout.addWidget(self.line)

        self.done = QPushButton(self.actiongroup)
        self.done.setObjectName(u"done")

        self.horizontalLayout.addWidget(self.done)


        self.horizontalLayout_2.addWidget(self.actiongroup)


        self.verticalLayout.addLayout(self.horizontalLayout_2)


        self.retranslateUi(EditItemsDialog)

        QMetaObject.connectSlotsByName(EditItemsDialog)
    # setupUi

    def retranslateUi(self, EditItemsDialog):
        EditItemsDialog.setWindowTitle(QCoreApplication.translate("EditItemsDialog", u"*TITLE ME*", None))
        self.groupBox_3.setTitle(QCoreApplication.translate("EditItemsDialog", u"Tags used in all libraries", None))
        self.searchused.setPlaceholderText(QCoreApplication.translate("EditItemsDialog", u"Search used tags...", None))
        self.groupBox_4.setTitle(QCoreApplication.translate("EditItemsDialog", u"Tags on all items", None))
        self.searchall.setPlaceholderText(QCoreApplication.translate("EditItemsDialog", u"Search all tags...", None))
        self.addall.setPlaceholderText(QCoreApplication.translate("EditItemsDialog", u"Add tag to all...", None))
        self.groupBox_5.setTitle(QCoreApplication.translate("EditItemsDialog", u"Tags on selected items", None))
        self.searchsel.setPlaceholderText(QCoreApplication.translate("EditItemsDialog", u"Search selected tags...", None))
        self.addsel.setPlaceholderText(QCoreApplication.translate("EditItemsDialog", u"Add tag to selected...", None))
        self.actiongroup.setTitle(QCoreApplication.translate("EditItemsDialog", u"*TITLE ME*", None))
        self.confirmall.setText(QCoreApplication.translate("EditItemsDialog", u"All", None))
        self.confirmsel.setText(QCoreApplication.translate("EditItemsDialog", u"Selected", None))
        self.done.setText(QCoreApplication.translate("EditItemsDialog", u"Done", None))
    # retranslateUi

