# qt.
from PySide6.QtWidgets import QDialog, QWidget

# filebrary.
from gui.ui_dialog_download import Ui_DownloadDialog



class DownloadDialog(QDialog):
    def __init__(self, p_parent: QWidget):
        super().__init__(p_parent)

        self._ui: Ui_DownloadDialog = Ui_DownloadDialog()
        self._ui.setupUi(self)
