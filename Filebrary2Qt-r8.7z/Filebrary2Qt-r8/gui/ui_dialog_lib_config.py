# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ui_dialog_lib_config.ui'
##
## Created by: Qt User Interface Compiler version 6.3.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QCheckBox, QDialog, QFrame,
    QGridLayout, QLabel, QPushButton, QSizePolicy,
    QWidget)

class Ui_ConfigLibDialog(object):
    def setupUi(self, ConfigLibDialog):
        if not ConfigLibDialog.objectName():
            ConfigLibDialog.setObjectName(u"ConfigLibDialog")
        ConfigLibDialog.resize(400, 98)
        self.gridLayout = QGridLayout(ConfigLibDialog)
        self.gridLayout.setObjectName(u"gridLayout")
        self.label_2 = QLabel(ConfigLibDialog)
        self.label_2.setObjectName(u"label_2")
        sizePolicy = QSizePolicy(QSizePolicy.Minimum, QSizePolicy.Minimum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label_2.sizePolicy().hasHeightForWidth())
        self.label_2.setSizePolicy(sizePolicy)

        self.gridLayout.addWidget(self.label_2, 1, 0, 1, 1)

        self.label = QLabel(ConfigLibDialog)
        self.label.setObjectName(u"label")
        sizePolicy.setHeightForWidth(self.label.sizePolicy().hasHeightForWidth())
        self.label.setSizePolicy(sizePolicy)

        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)

        self.label_3 = QLabel(ConfigLibDialog)
        self.label_3.setObjectName(u"label_3")
        sizePolicy1 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Maximum)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.label_3.sizePolicy().hasHeightForWidth())
        self.label_3.setSizePolicy(sizePolicy1)
        self.label_3.setFrameShape(QFrame.Box)

        self.gridLayout.addWidget(self.label_3, 1, 1, 1, 1)

        self.pushButton = QPushButton(ConfigLibDialog)
        self.pushButton.setObjectName(u"pushButton")
        sizePolicy2 = QSizePolicy(QSizePolicy.Maximum, QSizePolicy.Maximum)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.pushButton.sizePolicy().hasHeightForWidth())
        self.pushButton.setSizePolicy(sizePolicy2)

        self.gridLayout.addWidget(self.pushButton, 1, 2, 1, 1)

        self.pushButton_2 = QPushButton(ConfigLibDialog)
        self.pushButton_2.setObjectName(u"pushButton_2")
        sizePolicy2.setHeightForWidth(self.pushButton_2.sizePolicy().hasHeightForWidth())
        self.pushButton_2.setSizePolicy(sizePolicy2)

        self.gridLayout.addWidget(self.pushButton_2, 0, 2, 1, 1)

        self.label_4 = QLabel(ConfigLibDialog)
        self.label_4.setObjectName(u"label_4")
        sizePolicy1.setHeightForWidth(self.label_4.sizePolicy().hasHeightForWidth())
        self.label_4.setSizePolicy(sizePolicy1)
        self.label_4.setFrameShape(QFrame.Box)

        self.gridLayout.addWidget(self.label_4, 0, 1, 1, 1)

        self.checkBox = QCheckBox(ConfigLibDialog)
        self.checkBox.setObjectName(u"checkBox")
        sizePolicy2.setHeightForWidth(self.checkBox.sizePolicy().hasHeightForWidth())
        self.checkBox.setSizePolicy(sizePolicy2)

        self.gridLayout.addWidget(self.checkBox, 2, 1, 1, 1)


        self.retranslateUi(ConfigLibDialog)

        QMetaObject.connectSlotsByName(ConfigLibDialog)
    # setupUi

    def retranslateUi(self, ConfigLibDialog):
        ConfigLibDialog.setWindowTitle(QCoreApplication.translate("ConfigLibDialog", u"Filebrary - Configure library", None))
        self.label_2.setText(QCoreApplication.translate("ConfigLibDialog", u"Path:", None))
        self.label.setText(QCoreApplication.translate("ConfigLibDialog", u"Name:", None))
        self.label_3.setText(QCoreApplication.translate("ConfigLibDialog", u"placeholder path", None))
        self.pushButton.setText(QCoreApplication.translate("ConfigLibDialog", u"Migrate...", None))
        self.pushButton_2.setText(QCoreApplication.translate("ConfigLibDialog", u"Rename...", None))
        self.label_4.setText(QCoreApplication.translate("ConfigLibDialog", u"placeholder name", None))
        self.checkBox.setText(QCoreApplication.translate("ConfigLibDialog", u"Arrange files by tags", None))
    # retranslateUi

