# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ui_dockpanel_search.ui'
##
## Created by: Qt User Interface Compiler version 6.3.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QAction, QBrush, QColor, QConicalGradient,
    QCursor, QFont, QFontDatabase, QGradient,
    QIcon, QImage, QKeySequence, QLinearGradient,
    QPainter, QPalette, QPixmap, QRadialGradient,
    QTransform)
from PySide6.QtWidgets import (QApplication, QLabel, QLineEdit, QListWidget,
    QListWidgetItem, QSizePolicy, QVBoxLayout, QWidget)
import filebrary_rc

class Ui_TagsDockPanel(object):
    def setupUi(self, TagsDockPanel):
        if not TagsDockPanel.objectName():
            TagsDockPanel.setObjectName(u"TagsDockPanel")
        TagsDockPanel.resize(280, 400)
        self.actionSearch = QAction(TagsDockPanel)
        self.actionSearch.setObjectName(u"actionSearch")
        icon = QIcon()
        icon.addFile(u":/icons/System/search-line.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.actionSearch.setIcon(icon)
        self.verticalLayout = QVBoxLayout(TagsDockPanel)
        self.verticalLayout.setSpacing(2)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(2, 2, 2, 2)
        self.search = QWidget(TagsDockPanel)
        self.search.setObjectName(u"search")
        self.verticalLayout_2 = QVBoxLayout(self.search)
        self.verticalLayout_2.setSpacing(0)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.label_2 = QLabel(self.search)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setAlignment(Qt.AlignCenter)

        self.verticalLayout_2.addWidget(self.label_2)

        self.searchbar = QLineEdit(self.search)
        self.searchbar.setObjectName(u"searchbar")
        self.searchbar.setClearButtonEnabled(True)

        self.verticalLayout_2.addWidget(self.searchbar)

        self.searchtags = QListWidget(self.search)
        self.searchtags.setObjectName(u"searchtags")
        self.searchtags.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)

        self.verticalLayout_2.addWidget(self.searchtags)


        self.verticalLayout.addWidget(self.search)

        self.included = QWidget(TagsDockPanel)
        self.included.setObjectName(u"included")
        self.verticalLayout_3 = QVBoxLayout(self.included)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(0, 0, 0, 3)
        self.label = QLabel(self.included)
        self.label.setObjectName(u"label")
        self.label.setAlignment(Qt.AlignCenter)

        self.verticalLayout_3.addWidget(self.label)

        self.taglist = QListWidget(self.included)
        self.taglist.setObjectName(u"taglist")
        self.taglist.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)

        self.verticalLayout_3.addWidget(self.taglist)


        self.verticalLayout.addWidget(self.included)

        self.verticalLayout.setStretch(0, 1)
        self.verticalLayout.setStretch(1, 2)

        self.retranslateUi(TagsDockPanel)

        QMetaObject.connectSlotsByName(TagsDockPanel)
    # setupUi

    def retranslateUi(self, TagsDockPanel):
        TagsDockPanel.setWindowTitle(QCoreApplication.translate("TagsDockPanel", u"Widget", None))
        self.actionSearch.setText(QCoreApplication.translate("TagsDockPanel", u"Search", None))
        self.label_2.setText(QCoreApplication.translate("TagsDockPanel", u"Search", None))
        self.searchbar.setPlaceholderText(QCoreApplication.translate("TagsDockPanel", u"Search tags...", None))
        self.label.setText(QCoreApplication.translate("TagsDockPanel", u"Tags on results", None))
    # retranslateUi

