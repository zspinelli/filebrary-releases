# filebrary.
from gui.ui_dockpanel_search import Ui_TagsDockPanel

from core import Library

# qt.
from PySide6.QtCore import Slot
from PySide6.QtWidgets import QLineEdit, QWidget



class SearchDockPanel(QWidget):
    def __init__(self, p_parent: QWidget):
        super().__init__(p_parent)

        self._ui: Ui_TagsDockPanel = Ui_TagsDockPanel()
        self._ui.setupUi(self)

        Library.signaller.searchCompleted.connect(self.syncTagsList)

        self._ui.searchbar.addAction(self._ui.actionSearch, QLineEdit.LeadingPosition)
        self._ui.searchbar.returnPressed.connect(self.searchInvoked)

        self._ui.actionSearch.triggered.connect(self.searchInvoked)



    @Slot()
    def syncTagsList(self):
        # Synchronize the list of tags to search results.

        self._ui.searchtags.clear()
        self._ui.searchtags.addItems(Library.lastSearchTerms())

        self._ui.taglist.clear()
        self._ui.taglist.addItems(Library.resultTags())



    @Slot()
    def searchInvoked(self):
        # Initiate a search through the libraries.

        if self._ui.searchbar.text() != "":
            tags: list[str] = self._ui.searchbar.text().split(';')
            tags = [tag.strip() for tag in tags]
            Library.search(tags)
