# filebrary.
from gui.ui_dockpanel_libs import Ui_LibsDockPanel

from core import Library
from gui.listing_libs_dock import LibsDockListing
from gui.dialog_lib_new import NewLibDialog

# qt.
from PySide6.QtCore import Slot
from PySide6.QtWidgets import QWidget, QFileDialog, QMessageBox, QListWidgetItem



class LibsDockPanel(QWidget):
    def __init__(self, p_parent: QWidget):
        super().__init__(p_parent)

        self._listings: dict[int, LibsDockListing] = {} # NOTE: {qitem_addr : docklisting}

        self._ui: Ui_LibsDockPanel = Ui_LibsDockPanel()
        self._ui.setupUi(self)

        Library.signaller.openDbsChanged.connect(self.syncLibsList)
        self.syncLibsList()



    def _listLib(self, p_lib_id: int):
        # Create a new listing tied to a library.

        item: QListWidgetItem = QListWidgetItem()
        item.setText(str(p_lib_id))
        self._ui.liblist.addItem(item)

        widget: LibsDockListing = LibsDockListing(item)
        self._ui.liblist.setItemWidget(item, widget)

        self._listings.update({id(item) : widget})



    @Slot()
    def syncLibsList(self):
        # Synchronize the displayed list of libraries to the list of open libs in Libs.py

        items: list[QListWidgetItem] = []
        item_ids: list[int] = []

        for i in range(self._ui.liblist.count()):
            item: QListWidgetItem = self._ui.liblist.item(i)
            items.append(item)
            item_ids.append(int(item.text()))

        # ---- Remove dead listings. ---- #

        for item in items:
            if not Library.openDbsIsOpenID(int(item.text())):
                row: int = self._ui.liblist.row(item)
                self._ui.liblist.takeItem(row)

        # ---- Add new listings. ---- #

        for lib_id in Library.openDbsIDs():
            # Lib needs listed.
            if lib_id not in item_ids:
                self._listLib(lib_id)



    @Slot()
    def on_newlib_clicked(self):
        # Open a dialog for the user to configure a new library.

        newlib: NewLibDialog = NewLibDialog(self)
        newlib.finalized.connect(self.newlibCallback)
        newlib.open()



    @Slot(str, str)
    def newlibCallback(self, p_path: str, p_name: str):
        # Process the path received from a NewLibDialog.

        Library.createDb(p_path, p_name)



    @Slot()
    def on_openlib_clicked(self):
        # Open a dialog for the user to choose an existing library to add.

        result: tuple = QFileDialog.getOpenFileNames(
            self,
            "Filebrary - Open existing libraries",
            filter= "Filebrary libraries(*.fbl)"
        )
        chosen_files: list = result[0]

        if len(chosen_files) > 0:
            for filename in chosen_files:
                Library.openDb(filename)



    @Slot()
    def on_unloadlib_clicked(self):
        # Unload the library.

        items: list[QListWidgetItem] = self._ui.liblist.selectedItems()
        num_libs: int = len(items)
        message: str = ""

        # Return if nothing to unload.
        if num_libs == 0:   return
        # Many libs.
        if num_libs > 1:    message = "selected libraries"
        # One lib.
        else:               message = f"{Library.openDbName(int(items[0].text()))}"

        choice: QMessageBox.StandardButton = QMessageBox.question(
            self,
            "Filebrary - Unload library",
            "Unload " + message + "?"
        )

        # User chose to unload the libraries.
        if choice == QMessageBox.Yes:
            for item in items:
                Library.closeDb(int(item.text()))



    @Slot()
    def on_deletelib_clicked(self):
        # Delete the library permanently.

        items: list[QListWidgetItem] = self._ui.liblist.selectedItems()
        num_items: int = len(items)
        message: str = ""

        # Return if nothing to delete.
        if num_items == 0:  return
        # Many libs.
        elif num_items > 1: message = "selected libraries"
        # One lib.
        else:               message = f"{Library.openDbName(int(items[0].text()))}"

        choice: QMessageBox.StandardButton = QMessageBox.question(
            self,
            "Filebrary - Delete library",
            "Delete " + message + "?"
        )

        # User chose to delete the libraries.
        if choice == QMessageBox.Yes:
            for item in items:
                Library.deleteDb(int(item.text()))
