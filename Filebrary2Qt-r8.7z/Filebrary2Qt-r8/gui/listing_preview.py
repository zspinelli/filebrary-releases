# filebrary.
from gui.ui_listing_preview import Ui_PreviewListing

# pyside6.
from PySide6.QtCore import QSize, Signal, QPoint
from PySide6.QtGui import QMouseEvent
from PySide6.QtWidgets import QLabel, QListWidgetItem, QSizePolicy



class PreviewListing(QLabel):
    PREVIEW_SIZE: int = 180

    menuClicked: Signal = Signal(QPoint)

    def __init__(self, p_item: QListWidgetItem):
        super().__init__()

        self.item: QListWidgetItem = p_item

        self._ui: Ui_PreviewListing = Ui_PreviewListing()
        self._ui.setupUi(self)

        widget_min_size: QSize = QSize(self.PREVIEW_SIZE, self.PREVIEW_SIZE)
        self.setMinimumSize(widget_min_size)

        p_item.setSizeHint(self.sizeHint())

        size_policy: QSizePolicy = self.sizePolicy()
        size_policy.setRetainSizeWhenHidden(True)
        self.setSizePolicy(size_policy)



    def mouseDoubleClickEvent(self, p_double_click: QMouseEvent):
        # Open the item preview.

        pass
