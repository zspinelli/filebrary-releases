# qt.
from PySide6.QtCore import QTranslator

# stdlib.
from configparser import ConfigParser
from os import getcwd
from typing import IO



translator: QTranslator = QTranslator()

_path: str = getcwd() + "/filebrary.ini"
_parser: ConfigParser = ConfigParser()



def write():
    # Write the config to file.

    config: IO = open(_path, "w")
    _parser.write(config)
    config.close()



def listSet(p_section: str, p_variable: str, p_value: list):
    # Set a sequence of values to a variable.

    # ---- Convert the listed values to strings and consolidate. ---- #

    joined: str = ""

    for value in p_value:
        value = str(value)
        joined += f"\n{value}"

    # ---- Store the value in the config. ---- #

    # Section doesn't exist yet.
    if not _parser.has_section(p_section):
        _parser.add_section(p_section)

    _parser.set(p_section, p_variable, joined)



def listGet(p_section: str, p_variable: str) -> list[str]:
    # Get a list of sequences from a variable.

    # ---- Query the config. ---- #

    got: str = _parser.get(p_section, p_variable, fallback= "")

    # ---- Prepare and return the result. ---- #

    values: list[str] = got.strip().split('\n')
    return values



def listAdd(p_section: str, p_variable: str, p_value):
    # Try adding a value to a list. No redundancy.

    new_value: str = f"\n{str(p_value)}"

    # Section doesn't exist yet.
    if not _parser.has_section(p_section):
        _parser.add_section(p_section)
        _parser.set(p_section, p_variable, new_value)

    # Section exists.
    else:
        old_value: str = _parser.get(p_section, p_variable, fallback="")

        # Variable already has a value.
        if old_value:
            # New value needs appended.
            if not new_value in old_value:
                new_value += old_value
                _parser.set(p_section, p_variable, new_value)



# Config isn't used as the main script.
if __name__ != "__main__":
    _parser.read(_path)
