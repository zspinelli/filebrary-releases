# stdlib.
import asyncio
import shutil
import sqlite3
from copy import deepcopy
from os import remove, mkdir, listdir
from os.path import dirname, basename, isfile, splitext, split, exists
from sqlite3 import Connection, OperationalError

# filebrary.
from core.database import Database
from core.record import Record
from core.signaller import Signaller
from core.term import Term, comprehendToTerm



_SQL_CREATE_NEW_DATABASE: str = (
    "CREATE TABLE library ("
    "url text NOT NULL PRIMARY KEY, "
    "name text, "
    "desc text, "
    "tags text"
    ")"
)
_SQL_SEARCH: str = "SELECT * FROM library WHERE "
_SQL_SEARCH_ALL: str = "SELECT * FROM library"
_SQL_ITERM_TEMPLATE: str = "tags LIKE \'%?%\'"
_SQL_XTERM_TEMPLATE: str = "tags NOT LIKE \'%?%\'"



signaller: Signaller = Signaller()

_databases: dict[int, Database] = {} # {memaddr : Database}
_search_results: list[Record] = []
_last_search: list[str] = []
_last_search_terms: list[str] = []



# ======================================================================================== #
# Database management.

def urlUnderDb(p_url: str) -> bool:
    # Returns true if the url is under a database.

    while '/' in p_url:
        p_url = p_url.rsplit('/', 1)[0]
        files: list[str] = listdir(p_url)

        for file in files:
            # Under a database.
            if splitext(file) == ".fbl":
                return True

    return False



def countUnderDb(p_url) -> int:
    # Returns the number of databases the url is under.

    count: int = 0

    while '/' in p_url:
        p_url = p_url.rsplit('/', 1)[0]
        files: list[str] = listdir(p_url)

        for file in files:
            # Found a database.
            if splitext(file) == ".fbl":
                count += 1

    return count



def openDbId(p_name: str) -> int:
    # Returns the id of an open database.

    for db in _databases.values():
        # The name matches an open database name.
        if db.name() == p_name:
            return id(db)

    return -1



def openDbName(p_id: int) -> str:
    # Returns the name of an open database.

    # The id matches the id of an open database.
    if p_id in _databases:
        return _databases[p_id].name()

    return ""



def createDb(p_path: str, p_name: str) -> int:
    # Create and open a new database. Returns status code.

    # NOTE:
    # Code  :   Meaning
    # 0     :   Creation successful.
    # 1     :   Already exists.
    # 2     :   Database present.
    # 3     :   Unknown reason. (Data corrupt? Drive detached?)

    filepath: str = f"{p_path}/{p_name}.fbl"

    # Filepath already taken.
    if isfile(filepath):
        return 1

    # The path exists under another database.
    elif urlUnderDb(dirname(p_path)):
        return 2

    # Filepath is available.
    else:
        try:
            connection: Connection = sqlite3.connect(filepath)
            connection.execute(_SQL_CREATE_NEW_DATABASE)

            new_db: Database = Database(p_name, p_path, connection)
            _databases.update({id(new_db) : new_db})

            signaller.emitOpenDbsChanged()
            return 0

        except OperationalError as error:
            print(error)
            return 3



def _delegatePathOpen(p_filepath: str) -> bool:
    # Returns if the filepath is an open database.

    for db in _databases:
        if _databases[db].filepath() == p_filepath:
            return True

    return False



def openDb(p_filepath: str) -> int:
    # Open an existing database. Returns status code.

    # todo: search the opened db and append results.

    # NOTE:
    # Code  :   Meaning
    # 0     :   Creation successful.
    # 1     :   Already exists.
    # 2     :   Already open.
    # 3     :   Unknown reason. (Data corrupt? Drive detached?)
    # 4     :   Exists in a library data path (Artificially protected area).

    # File not real.
    if not isfile(p_filepath):
        return 1

    # File is already open.
    elif _delegatePathOpen(p_filepath):
        return 2

    # Database is under a database path.
    elif countUnderDb(dirname(p_filepath)) > 1:
        return 4

    # File is real and unopened.
    else:
        try:
            name: str = splitext(basename(p_filepath))[0]
            connection: Connection = sqlite3.connect(p_filepath)

            new_db: Database = Database(name, dirname(p_filepath), connection)
            _databases.update({id(new_db) : new_db})

            signaller.emitOpenDbsChanged()
            return 0

        except OperationalError as error:
            print(error)
            return 3



def closeDb(p_id: int):
    # Close an open database.

    # todo: purge search results belonging to the closed db.

    if p_id in _databases:
        _databases[p_id].close()
        del _databases[p_id]

    signaller.emitOpenDbsChanged()



def deleteDb(p_id: int):
    # Close and delete an open database.

    # todo: purge search results belonging to the deleted db.

    if p_id in _databases:
        _databases[p_id].close()
        remove(_databases[p_id].filepath())
        del _databases[p_id]

    signaller.emitOpenDbsChanged()



# ======================================================================================== #
# Database statistics.

def openDbsIsOpenID(p_id: int) -> bool:
    # Returns if the id belongs to an open database.

    # ID belongs to a database.
    if p_id in _databases:
        return True

    return False



def openDbsCount() -> int:
    # Returns number of open databases.

    return len(_databases)



def openDbsIDs() -> list[int]:
    # Returns a list of unique identifiers.

    return list(_databases.keys())



def openDbsNames() -> list[str]:
    # Returns a list of open database names.

    names: list[str] = []

    for db in _databases:
        names.append(_databases[db].name())

    return names



def openDbsFilepaths() -> list[str]:
    # Returns a list of open database filepaths.

    filepaths: list[str] = []

    for db in _databases:
        filepaths.append(_databases[db].filepath())

    return filepaths



# ======================================================================================== #
# Record management.

def dbIgnored(p_id: int) -> bool:
    # Returns if the database should be ignored in searches.

    return _databases[p_id].ignore



def setDbIgnored(p_id: int, p_ignored: bool):
    # Set a database to be ignored in searches.

    _databases[p_id].ignore = p_ignored



def addRecords(p_additions: list[Record]) -> list[str]:
    # Add records to a database. Returns a list of successfully added urls.

    # todo: search additions and add to search results.

    added: list[str] = []

    for rec in p_additions:
        db: Database = _databases[rec.db()]

        filename: str = split(rec.url())[1]
        copy_filepath: str = f"{db.path()}/{db.name()}/{filename}"
        copy_dir: str = dirname(copy_filepath)

        new_rec = Record(
            copy_filepath,
            rec.name(),
            rec.desc(),
            rec.tags(),
            rec.db()
        )

        # Url is not in a database or already used, and record was added.
        if(
            not urlUnderDb(rec.url()) and
            not db.hasUrl(copy_filepath) and
            db.addRecord(new_rec)
        ):
            # Required folder tree doesn't exist.
            if not exists(copy_dir): mkdir(copy_dir)

            shutil.copyfile(rec.url(), copy_filepath)
            added.append(rec.url())

    print("Library::addRecords()\n", added)
    return added



def editRecords(p_editions: list[Record]) -> list[str]:
    # Edit records in a database. Returns a list of successfully edited urls.

    # todo: search modifications and update search results.

    edited: list[str] = []

    for rec in p_editions:
        db: Database = _databases[rec.db()]

        # Record was edited.
        if db.editRecord(rec.url(), rec): edited.append(rec.url())

    return edited



def deleteRecords(p_deletions: list[Record]) -> list[str]:
    # Delete records from a database. Returns a list of successfully deleted urls.

    # todo: purge deleted records from search results.

    deleted: list[str] = []

    for rec in p_deletions:
        db: Database = _databases[rec.db()]

        # Record was deleted.
        if db.deleteRecord(rec.url()): deleted.append(rec.url())

    return deleted



# ======================================================================================== #
# Results.

def lastSearchTerms() -> list[str]:
    # Returns the last terms used to search.

    return _last_search_terms



def allTags() -> list[str]:
    # Returns all tags used in all databases.

    tags: list[str] = []

    for db_id in _databases:
        found: list[Record] = _databases[db_id].search(db_id, _SQL_SEARCH_ALL, [])

        for rec in found:
            tags += rec.tags()

    tags.sort()

    return tags



def resultTags() -> list[str]:
    # Returns all tags used in the search results.

    tags: list[str] = []

    for rec in _search_results:
        #print(rec.tags())
        tags.extend(rec.tags())

    tags = list(set(tags))

    return tags



def searchResultsCount() -> int:
    # Returns the number of search results.

    return len(_search_results)



def searchResults() -> list[Record]:
    # Returns a list of search results.

    return deepcopy(_search_results)



def resultAtIndex(p_index: int) -> Record:
    # Returns the record at the given index.

    return _search_results[p_index]



async def _delegateDbSearchAsync(p_params: tuple[int, str, list[Term]]): # -> list[Record]
    # Searches all the databases asynchronously.

    # Ignore this database.
    if _databases[p_params[0]].ignore:
        return []

    # Search this database.
    else:
        return _databases[p_params[0]].search(*p_params)



async def _delegateSearchAsync(p_search: str, p_terms: list[Term]): # -> list[Record]
    # Search all the databases asynchronously.

    results: list[Record] = []

    param_sets: list[tuple] = [(key, p_search, p_terms) for key in _databases]

    for future in asyncio.as_completed(map(_delegateDbSearchAsync, param_sets)):
        result = await future

        # Future returned something useful.
        if result != []: results.extend(result)

    return results



def search(p_terms: list[str]):
    # Search the databases for matching records.

    global _search_results
    global _last_search_terms

    terms: list[Term] = []
    sql_terms: list[str] = []
    sql_search: str = ""

    _last_search_terms.clear()

    # Find everything.
    if "*" in p_terms:
        sql_search = _SQL_SEARCH_ALL
        _last_search_terms.append("* (Everything)")

    # Search with terms.
    else:
        for candidate in p_terms:
            new_term: Term = comprehendToTerm(candidate)

            # Term is valid type.
            if new_term.type() != Term.INVALID:
                if new_term.exclusive():    sql_terms.append(_SQL_XTERM_TEMPLATE.replace('?', new_term.root()))
                else:                       sql_terms.append(_SQL_ITERM_TEMPLATE.replace('?', new_term.root()))

                _last_search_terms.append(candidate)

        sql_search = _SQL_SEARCH + " AND ".join(sql_terms)
        #print("Search:", sql_search)

    # ---- Begin the search. ---- #

    _search_results = asyncio.run(_delegateSearchAsync(sql_search, terms))
    print("Results: ", searchResultsCount())

    signaller.emitSearchCompleted(searchResultsCount())
    #print(searchResultsCount())
