
class _LimitExtension:
    def __init__(self, p_limit: int):
        self._limit: int = p_limit

    def __str__(self):
        return f"Limit: limit={self._limit}"

    def limit(self) -> int:         return self._limit



class _RangeExtension:
    def __init__(self, p_lower: int, p_upper: int):
        self._lower: int = p_lower
        self._upper: int = p_upper

    def __str__(self):
        return f"Range: lower={self._lower} upper={self._upper}"

    def lower(self) -> int:     return self._lower
    def upper(self) -> int:     return self._upper



class _SetExtension:
    def __init__(self, p_values: list[str]):
        self._values: list[str] = p_values

    def __str__(self):
        return f"Set: values={self._values}"

    def values(self) -> list[str]:  return self._values



class Term:
    # Types.
    INVALID = -1
    WHOLE = 0
    LIMIT_G = 1
    LIMIT_L = 2
    RANGE = 3
    SET = 4

    def __init__(self, p_root: str, p_exclusive: bool, p_type: int, p_extension):
        self._root: str = p_root
        self._exclusive: bool = p_exclusive
        self._type: int = p_type
        self._extension = p_extension

    def root(self) -> str:          return self._root
    def type(self) -> int:          return self._type
    def exclusive(self) -> bool:    return self._exclusive
    def extension(self):            return self._extension



def _delegatePreprocess(p_cand: str) -> str:
    # Perform basic preprocessing on the candidate.

    # ---- Remove excess, troublesome, and invalid whitespace chars. ---- #

    p_cand = p_cand.replace('\n', ' ')
    p_cand = p_cand.replace('\t', ' ')

    p_cand = p_cand.strip()

    while "  " in p_cand:
        p_cand = p_cand.replace("  ", " ")

    # ---- Correct excess colons. ---- #

    p_cand = p_cand.lstrip(':')

    while "::" in p_cand:
        p_cand = p_cand.replace("::", ":")

    p_cand = p_cand.replace(" :", ":")
    p_cand = p_cand.replace(": ", ":")

    return p_cand



def _delegateDecapsulate(p_capsule: str) -> list[str]:
    # Extract an encapsulated set of values.

    p_capsule = p_capsule[1:-1]
    p_capsule = p_capsule.replace(" ,", ",")
    p_capsule = p_capsule.replace(", ", ",")

    return p_capsule.split(',')



def comprehendToTerm(p_cand: str) -> Term:
    # Parse a string candidate into a term.

    root: str = ""
    exclusive: bool = False
    term_type: int = Term.INVALID
    extension = None

    # ---- Correct simple typos. ---- #

    p_cand = _delegatePreprocess(p_cand)

    # ---- Detect term root. ---- #

    last_colon_index: int = p_cand.rfind(':')
    root = p_cand[:last_colon_index + 1]

    # ---- Detect term exclusivity. ---- #

    # Candidate begins with minus.
    if root[0] == "-":
        exclusive = True
        root = root[1:]

    # ---- Detect term type. ---- #

    value_part: str = p_cand.rsplit(':', 1)[1]

    # Candidate is an open field whole.
    if value_part == '':
        term_type = Term.WHOLE


    # Candidate is a lesser limit.
    elif value_part[0] == '<':
        limit: str = value_part[1:]

        # Limit parameter is non-numeric (bad).
        if not limit.isnumeric():
            return Term("", False, Term.INVALID, None)

        term_type = Term.LIMIT_L
        extension = _LimitExtension(int(limit))


    # Candidate is a greater limit.
    elif value_part[0] == '>':
        limit: str = value_part[1:]

        # Field parameter non-numeric.
        if not limit.isnumeric():
            return Term("", False, Term.INVALID, None)

        term_type = Term.LIMIT_G
        extension = _LimitExtension(int(limit))


    # Candidate is a range.
    elif value_part[0] == '[':
        range_param: str = value_part[1:]

        # Range parameter not encapsulated with brackets.
        if ']' not in range_param or range_param[-1] != ']':
            return Term("", False, Term.INVALID, None)

        # ---- Validate the bounds. ---- #

        bounds: list[str] = _delegateDecapsulate(range_param)

        # Too many or non-numeric range parameters.
        if(
            len(bounds) > 2 or
            not bounds[0].isnumeric() or
            not bounds[1].isnumeric()
        ):
            return Term("", False, Term.INVALID, None)

        # ---- Create the extension. ---- #

        term_type = Term.RANGE
        extension = _RangeExtension(int(bounds[1]), int(bounds[2]))


    # Candidate is a set.
    elif value_part[0] == '(':
        set_param: str = value_part[1:]

        # Set parameter not encapsulated with parenthesis.
        if ')' not in set_param or set_param[-1] != ')':
            return Term("", False, Term.INVALID, None)

        set_values: list[str] = _delegateDecapsulate(set_param)

        # ---- Create the extension. ---- #

        term_type = Term.SET
        extension = _SetExtension(set_values)

    else:
        term_type = Term.WHOLE

    # ---- Create the term instance. ---- #

    #print(f"{'Root:':<24}{root}")
    #print(f"{'Exclusive:':<24}{exclusive}")
    #print(f"{'Type:':<24}{term_type}")
    #print(f"{'Extension:':<24}{extension}")

    return Term(root, exclusive, term_type, extension)
