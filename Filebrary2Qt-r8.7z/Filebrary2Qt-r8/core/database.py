# stdlib.
import sqlite3
from os import rename
from os.path import isfile
from sqlite3 import Connection, Cursor, OperationalError

# filebrary.
from core.record import Record
from core.term import Term



class Database:
    _SQL_HAS_RECORD: str = "SELECT url FROM library WHERE url = ?"
    _SQL_ADD_RECORD: str = "INSERT INTO library (url, name, desc, tags) values (?, ?, ?, ?)"
    _SQL_EDIT_RECORD: str = "UPDATE library SET url=?, name=?, desc=?, tags=? WHERE url = ?"
    _SQL_DELETE_RECORD: str = "DELETE FROM library WHERE url = ?"

    def __init__(self, p_name: str, p_path, p_connection: Connection, p_ignore: bool= False):
        self._name: str = p_name
        self._path: str = p_path
        self._connection: Connection = p_connection
        self.ignore: bool = p_ignore



    def name(self) -> str:  return self._name
    def path(self) -> str:  return self._path



    def filepath(self) -> str:
        # Returns the filepath to the sqlite database.

        return f"{self._path}/{self._name}.fbl"



    def rename(self, p_name) -> int:
        # Rename the database. Returns status code.

        # NOTE:
        # Code  :   Meaning
        # 0     :   Renamed successfully.
        # 1     :   Filepath taken.
        # 2     :   Database unavailable. (In use? Drive detached?)

        old_filepath: str = f"{self._path}/{self._name}.fbl"
        new_filepath: str = f"{self._path}/{p_name}.fbl"

        # Filepath taken.
        if isfile(new_filepath):
            return 1

        # Filepath available.
        else:
            try:
                self._connection.commit()
                self._connection.close()

                rename(old_filepath, new_filepath)

                self._connection = sqlite3.connect(new_filepath)
                return 0

            except OperationalError as error:
                print(error)
                return 2



    def close(self):
        # Close the database.

        self._connection.commit()
        self._connection.close()



    def hasUrl(self, p_url: str) -> bool:
        # Returns if the url is present in the database.

        try:
            cursor: Cursor = self._connection.cursor()
            cursor.execute(self._SQL_HAS_RECORD, (p_url,))

            # Query found nothing.
            if len(cursor.fetchall()) < 1:
                return False

            return True

        except OperationalError as error:
            print(error)
            return False



    def addRecord(self, p_record: Record) -> bool:
        # Add a record to the database.

        try:
            cursor: Cursor = self._connection.cursor()
            cursor.execute(self._SQL_ADD_RECORD, p_record.toTuple())
            self._connection.commit()
            return True

        except OperationalError as error:
            print("database::addRecord()", error)
            return False



    def exportRecord(self):
        # .

        pass



    def editRecord(self, p_url: str, p_record: Record) -> bool:
        # Edit a record in the database.

        try:
            cursor: Cursor = self._connection.cursor()
            cursor.execute(self._SQL_EDIT_RECORD, (
                p_record.url(),
                p_record.name(),
                p_record.desc(),
                p_record.tagsStr(),
                p_url
            ))
            self._connection.commit()
            return True

        except OperationalError as error:
            print("", error)
            return False



    def deleteRecord(self, p_url: str) -> bool:
        # Delete a record from the database.

        #todo: delete the associated file.

        try:
            cursor: Cursor = self._connection.cursor()
            cursor.execute(self._SQL_DELETE_RECORD, (p_url,))
            self._connection.commit()
            return True

        except OperationalError as error:
            print("database::deleteRecord()", error)
            return False



    def _delegateRecordsFromTuple(self, p_id: int, p_tuples: list[tuple]) -> list[Record]:
        # Generate a record from the given tuple.

        records: list[Record] = []

        for tup in p_tuples:
            new_record: Record = Record(
                tup[0],                                             # url.
                tup[1].strip(),                                     # name.
                tup[2].strip(),                                     # desc.
                [tag for tag in tup[3].split('|') if tag.strip()],  # tags
                p_id                                                # db.
            )

            records.append(new_record)

        return records



    def search(self, p_db_id: int, p_query: str, p_terms: list[Term]) -> list[Record]:
        # Search the database. Returns list of matching records.

        results: list[Record] = []

        try:
            cursor: Cursor = self._connection.cursor()
            cursor.execute(p_query)
            results = self._delegateRecordsFromTuple(p_db_id, cursor.fetchall())

        except OperationalError as error:
            print("database::search()", error)
            return []

        # ---- Filter the results. ---- #

        checks = len(p_terms)

        for i in range(len(results)):
            result: Record = results[-1]
            checks_passed: int = 0

            # ---- Pass all checks or delete. ---- #

            for term in p_terms:
                for tag in result.tags():
                    # Whole term.
                    if(
                        term.type() == Term.WHOLE and
                        (term.exclusive and term.root() in tag) or
                        (not term.exclusive and term.root() not in tag)
                    ):
                        del results[-1]
                        continue

                    # Greater limit term.
                    elif term.type() == Term.LIMIT_G:
                        value: str = tag.rsplit(':')[-1]

                        # Value isn't numeric or outside the limit.
                        if not value.isnumeric() or not int(value) > term.extension().limit():
                            del results[-1]
                            continue

                    # Limit term.
                    elif term.type() == Term.LIMIT_L:
                        value: str = tag.rsplit(':')[-1]

                        # Value isn't numeric or outside the limit.
                        if not value.isnumeric() or not int(value) < term.extension().limit():
                            del results[-1]
                            continue

                    # Range term.
                    elif term.type() == Term.RANGE:
                        value: str = tag.rsplit(':')[-1]

                        # Value isn't numeric or is outside the range bounds.
                        if not value.isnumeric() or term.extension().lower() < int(value) < term.extension().upper():
                            del results[-1]
                            continue

                    # Set term.
                    elif term.type == Term.SET:
                        value: str = tag.rsplit(':')[-1]

                        # Value isn't in the set of desired values.
                        if value not in term.extension().values():
                            del results[-1]
                            continue

            if checks_passed != checks:
                del results[i]

        return results
