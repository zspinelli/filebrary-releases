# qt.
from PySide6.QtCore import QObject, Signal



class Signaller(QObject):
    openDbsChanged: Signal = Signal()
    searchCompleted: Signal = Signal(int)
    resultsModified: Signal = Signal()

    def __init__(self):
        super().__init__()

    def emitOpenDbsChanged(self):   self.openDbsChanged.emit()
        # Emits whenever a database is created, opened, or closed.

    def emitSearchCompleted(self, p_val):   self.searchCompleted.emit(p_val)
        # Emits whenever a search is completed.

    def emitResultsModified(self):  self.resultsModified.emit()
        # Emits whenever the search results are changed outside of a search.
