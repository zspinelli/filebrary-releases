# stdlib.
from copy import copy



class Record:
    def __init__(self, p_url: str, p_name: str, p_desc: str, p_tags: list[str], p_db: int= -1):
        self._url: str = p_url
        self._name: str = p_name
        self._desc: str = p_desc
        self._tags: list[str] = p_tags
        self._db: int = p_db



    def url(self) -> str:               return self._url
    def name(self) -> str:              return self._name
    def desc(self) -> str:              return self._desc
    def tags(self) -> list[str]:        return copy(self._tags)
    def tagsStr(self) -> str:           return '|'.join(self._tags)
    def db(self) -> int:                return self._db



    def toTuple(self) -> tuple:
        # Returns the record data in a tuple.

        return (self._url, self._name, self._desc, self.tagsStr())
