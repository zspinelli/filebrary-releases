# filebrary.
import EvalForms
import Config
from core import Library
from gui.mainwindow import MainWindow

# qt.
from PySide6.QtWidgets import QApplication

# stdlib.
from sys import argv



def _preshutdown():
    # Do anything that needs to be done before exiting.

    # ---- Write the config file. ---- #

    Config.listSet("resume", "openlibs", Library.openDbsFilepaths())
    Config.write()



if __name__ == "__main__":
    # ---- Resume previous libraries. ---- #

    open_libs: list[str] = Config.listGet("resume", "openlibs")

    for lib in open_libs:
        Library.openDb(lib)
        # TODO: report errors to the user.

    # ---- Create the application. --- #

    app: QApplication = QApplication(argv)

    app.setOrganizationName("Starfleet")
    app.setOrganizationDomain("gitlab")
    app.setApplicationName("Filebrary")

    app.installTranslator(Config.translator)

    app.aboutToQuit.connect(_preshutdown)

    # ---- Start the GUI. ---- #

    window: MainWindow = MainWindow()

    exit(app.exec())
